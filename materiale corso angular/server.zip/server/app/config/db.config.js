module.exports = {
   // url: "mongodb://localhost:27017/angular_crud_db"
   //nuovo url se il localhost non dovesse funzionare
   url: "mongodb://127.0.0.1:27017/db_cibando"
  };
